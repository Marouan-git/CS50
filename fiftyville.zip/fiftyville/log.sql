-- Keep a log of any SQL queries you execute as you solve the mystery.

-- Read crime scene report that matches the date and the location of the crime
SELECT description FROM crime_scene_reports WHERE day = 28 AND month = 7 AND year = 2020 AND street = "Chamberlin Street";

-- Read interviews conducted the day of the crime
SELECT transcript FROM interviews WHERE year = 2020 AND month = 7 AND day = 28;

-- Find license plates that left the parking lot within ten minutes of the theft
SELECT license_plate FROM courthouse_security_logs WHERE day = 28 AND month = 7 AND year = 2020 AND hour = 10 AND (minute > 15 AND minute < 26);

-- Find names of people who took a flight the day after the crime it took place
SELECT name FROM people p, passengers pa, flights f, airports a WHERE p.passport_number = pa.passport_number AND pa.flight_id = f.id AND f.year = 2020
AND f.month = 7 AND f.day = 29 AND f.origin_airport_id = a.id AND a.city = "Fiftyville";

-- Find names of people who withdrew money the day the crime took place
SELECT name FROM people p, bank_accounts b, atm_transactions a WHERE p.id = b.person_id AND b.account_number = a.account_number AND a.year = 2020
AND a.month = 7 AND a.day = 28 AND a.atm_location = "Fifer Street";

-- Find names of people who had a call phone that lasted less than one minute right after the crime took place
SELECT name FROM people p, phone_calls pc WHERE p.phone_number = pc.caller AND pc.year = 2020 AND pc.month = 7 AND pc.day = 28 AND pc.duration < 60;

-- Find the name of the thief
SELECT name FROM people p, courthouse_security_logs c WHERE
p.license_plate IN (SELECT license_plate FROM courthouse_security_logs WHERE day = 28 AND month = 7 AND year = 2020 AND hour = 10 AND (minute > 15 AND minute < 26))
AND p.name IN (SELECT name FROM people p1, passengers pa, flights f, airports a WHERE p1.passport_number = pa.passport_number
AND pa.flight_id IN (SELECT f1.id FROM flights f1, airports a1 WHERE f1.year = 2020
AND f1.month = 7 AND f1.day = 29 AND f1.origin_airport_id = a1.id AND a1.city = "Fiftyville" ORDER BY f1.hour, f1.minute LIMIT 1))
AND p.name IN (SELECT name FROM people p2, bank_accounts b, atm_transactions at WHERE p2.id = b.person_id AND b.account_number = at.account_number AND at.year = 2020
AND at.month = 7 AND at.day = 28 AND at.atm_location = "Fifer Street")
AND p.name IN (SELECT name FROM people p3, phone_calls pc WHERE p3.phone_number = pc.caller AND pc.year = 2020 AND pc.month = 7 AND pc.day = 28 AND pc.duration < 60);

-- Find the city where the thief escaped to
SELECT DISTINCT city FROM airports a, flights f, passengers pa, people p WHERE
p.name = "Ernest"
AND p.passport_number = pa.passport_number
AND pa.flight_id IN (SELECT f1.id FROM flights f1, airports a1 WHERE f1.year = 2020 AND f1.month = 7 AND f1.day = 29 AND f1.origin_airport_id = a1.id AND a1.city = "Fiftyville" ORDER BY f1.hour, f1.minute LIMIT 1)
AND pa.flight_id = f.id
AND f.destination_airport_id = a.id;

-- Find the accomplice
SELECT name FROM people p, phone_calls pc WHERE p.phone_number = pc.receiver 
AND pc.year = 2020 AND pc.month = 7 AND pc.day = 28 
AND pc.duration < 60
AND pc.caller IN (SELECT phone_number FROM people WHERE name = "Ernest");